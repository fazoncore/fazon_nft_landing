# FAZON BOOK I — NFT TIER I Landing

## ENGLISH:
This landing page promotes the FAZON BOOK I: Theory of Coincidence.
You can:
- View the project description
- Connect your MetaMask wallet
- Purchase or access the NFT
- Enter the book through gated access (Tier I)

## РУССКИЙ:
Это лендинг для книги FAZON BOOK I (Теория Совпадения).
Вы можете:
- Прочитать описание проекта
- Подключить MetaMask
- Приобрести или активировать NFT
- Получить доступ к книге (TIER I)

Contact: fazon@fazoncore.org
Website: https://fazon.org
